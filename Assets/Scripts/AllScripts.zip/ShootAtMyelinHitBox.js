﻿//function OnMouseDown(){
//	Debug.Log("hitboxscriptworking");
//	ShootAtMyelin.MouseClicked();
	
//}