﻿var startTime : float;
var enemy : Transform; //Your enemy prefab
 
function Update(){

   /* By Time (Not Yet Tested)
    if (startTime == 0) //New time
    {
        startTime = Time.time; //Set the current time
    }
    else
    {
        if ((Time.time - startTime) == 120) //Check if 120 seconds have passed
        {
            startTime = 0; //Set the starttime back to 0
            Instantiate (enemy, transform.FindChild("PlayerTargetSpawnPoint"), Quaternion.identity); //Create an enemy (transform, position, rotation)
        }
    }
    */
    
    
    
}